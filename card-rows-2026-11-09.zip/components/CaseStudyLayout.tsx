// Destination: components/CaseStudyLayout.tsx
import Image from "next/image";
import Link from "next/link";
import type { ReactNode } from "react";
import { BrowserFrame } from "@/components/BrowserFrame";
import { VideoWithPlayOverlay } from "@/components/VideoWithPlayOverlay";
import { CollapsibleSection } from "@/components/CollapsibleSection";
import { JsonLd } from "@/components/JsonLd";
import { KeepHyphens } from "@/components/KeepHyphens";


interface MetadataItem {
  label: string;
  value: string;
}

interface CaseStudyImage {
  src: string;
  alt: string;
  /** Optional poster image, used only when src is a video (.mp4/.webm). */
  poster?: string;
}

interface Outcome {
  headline: string;
  description: string;
}

interface RelatedCaseStudy {
  slug: string;
  eyebrow: string;
  title: string;
  description: string;
  image: string;
}

interface ProjectShowcase {
  /** Optional anchor id, so another page can deep-link straight to this
   *  showcase (e.g. /work/ai-native-product-design-lab#ai-patient-support).
   *  Rendered with scroll-mt to clear the fixed 88px header. */
  id?: string;
  eyebrow: string;
  title: string;
  description: string[];
  images?: {
    src: string;
    alt: string;
    /** When set, wraps this image in a BrowserFrame with the given URL bar label.
     *  Optional `aspectRatio` (W/H as a number, e.g. 4/3 or 16/10) forces a
     *  uniform viewport size — use when pairing two browser-framed images in
     *  a grid that need to render at exactly the same height. */
    browserFrame?: { url: string; aspectRatio?: number };
    /** Optional max-width utility (e.g. "max-w-xl") to cap a single image's
     *  rendered size; the image is centered when set. */
    maxWidthClass?: string;
  }[];
  /** Optional call-to-action links (e.g. "Try it" buttons for live apps). External links open in new tab. */
  links?: { label: string; href: string }[];
  /** Optional custom JSX rendered BEFORE the images block. Use when the lead
   *  visual is a walkthrough reel and the stills are supporting detail. */
  customContentBefore?: ReactNode;
  /** Optional custom JSX rendered after the images block (e.g. a TiltedPhonePair). */
  customContent?: ReactNode;
}

interface CaseStudyLayoutProps {
  eyebrow: string;
  /** Title — accepts a string OR ReactNode. Wrapping is handled by text-balance
   *  on the h1, so manual <br /> breaks are not needed. ReactNode is kept here
   *  to support inline emphasis (<em>, <span>) if a case study wants it. */
  title: ReactNode;
  subtitle: string;
  heroImage: string;
  heroImageAlt: string;
  /** Optional. When provided, the hero renders this video (with an always-visible
   *  play affordance) in place of heroImage, in the same 16:9 hero container.
   *  heroImage is still used as the video's poster/fallback. */
  heroVideo?: { src: string; poster?: string; ariaLabel: string };
  /** Optional. When provided, this node replaces the standard 16:9 hero box
   *  entirely (e.g. a TiltedPhonePair of demo recordings). heroImage/heroVideo
   *  are ignored for the hero when this is set. */
  heroSlot?: ReactNode;
  metadata: MetadataItem[];
  challenge: string[];
  approach: ReactNode[];
  pullQuote?: string | string[];
  /** Optional ReactNode rendered immediately below the pull quote, before the
   *  approach. Used to lift a key visual (e.g. a progression) high on the page. */
  afterQuote?: ReactNode;
  /** First look (November 2026): the page's first work visual, rendered
   *  directly under the metadata block and ahead of the challenge, so the
   *  reader sees the work before the prose. Pass a block that brings its own
   *  container (a CaseStudyCarousel, a showcase section). For a plain image
   *  pair use firstLookImages instead. Measured across the six case studies,
   *  this halves the scroll to the first work visual. */
  firstLook?: ReactNode;
  /** First look as an image or video pair, same grid as midImages. */
  firstLookImages?: CaseStudyImage[];
  midImages?: CaseStudyImage[];
  /** Optional carousel slot rendered between the approach section and outcomes. */
  processCarousel?: ReactNode;
  /** Optional per-project showcases (eyebrow + title + description + images per project). Rendered after approach. */
  projectShowcases?: ProjectShowcase[];
  outcomes: Outcome[];
  bottomImages?: CaseStudyImage[];
  /** Optional full-width hero image rendered just before the closer section. */
  closerHero?: { src: string; alt: string };
  closer: ReactNode[];
  ctaHeadline: string;
  related?: RelatedCaseStudy[];
  /** JSON-LD for this case study (Article plus breadcrumbs), built with
   *  caseStudyGraph() from lib/seo.ts so it matches the page metadata. */
  structuredData?: object | object[];
  /** Optional compact block after the project showcases, before Selected
   *  outcomes. Used for small archives (e.g. the Lab's Earlier experiments)
   *  that should not carry the weight of a full showcase. */
  afterShowcases?: ReactNode;
}

function isAnimated(src: string): boolean {
  return src.endsWith(".gif");
}

function isVideo(src: string): boolean {
  return src.endsWith(".mp4") || src.endsWith(".webm");
}

/** Image or video grid shared by firstLookImages and midImages. Supports
 *  .mp4/.webm (auto-plays muted, loops). One item renders full-width 16:9;
 *  two or more render 2-up. */
function ImageGrid({ images }: { images: CaseStudyImage[] }) {
  return (
    <div
      className={`grid gap-6 md:gap-8 ${
        images.length === 1 ? "grid-cols-1" : "grid-cols-1 md:grid-cols-2"
      }`}
    >
      {images.map((img) => (
        <div
          key={img.src}
          className="relative aspect-[16/9] rounded-2xl overflow-hidden border border-border-default"
        >
          {isVideo(img.src) ? (
            <video
              src={img.src}
              poster={img.poster}
              autoPlay
              loop
              muted
              playsInline
              preload="metadata"
              aria-label={img.alt}
              className="absolute inset-0 w-full h-full object-cover"
            />
          ) : (
            <Image
              src={img.src}
              alt={img.alt}
              fill
              className="object-cover"
              unoptimized={isAnimated(img.src)}
              sizes="(max-width: 768px) 100vw, (max-width: 1280px) 90vw, 1100px"
            />
          )}
        </div>
      ))}
    </div>
  );
}

export function CaseStudyLayout(props: CaseStudyLayoutProps) {
  const quotes = props.pullQuote
    ? Array.isArray(props.pullQuote)
      ? props.pullQuote
      : [props.pullQuote]
    : [];
  const leadQuote = quotes[0];
  const restQuotes = quotes.slice(1);

  return (
    <article>
      {props.structuredData && <JsonLd data={props.structuredData} />}
      {/* ============================================================
          HERO
          Eyebrow + title + subtitle + hero image + metadata block.
          The lead pull quote now opens the challenge section (see below).
          ============================================================ */}
      <section className="relative section-hero">
        <div className="max-w-content mx-auto px-6 md:px-8 lg:px-12">
          <Link
            href="/work"
            className="inline-flex items-center text-sm font-medium text-text-tertiary hover:text-text-primary transition-colors mb-10 md:mb-12"
          >
            <span aria-hidden="true" className="mr-2">←</span> All work
          </Link>

          <p className="eyebrow">{props.eyebrow}</p>
          <h1 className="headline-static hero-title text-balance max-w-4xl">
            <KeepHyphens>{props.title}</KeepHyphens>
          </h1>
          <p className="hero-lead max-w-3xl">
            {props.subtitle}
          </p>

          {/* Hero — custom slot (e.g. tilted phones) if provided, else video, else image. */}
          {props.heroSlot ? (
            <div className="mt-12 md:mt-16">{props.heroSlot}</div>
          ) : (
            <div className="mt-12 md:mt-16 relative aspect-[16/9] rounded-2xl overflow-hidden border border-border-default">
              {props.heroVideo ? (
                <VideoWithPlayOverlay
                  src={props.heroVideo.src}
                  poster={props.heroVideo.poster ?? props.heroImage}
                  ariaLabel={props.heroVideo.ariaLabel}
                  wrapperClassName="absolute inset-0 w-full h-full"
                  videoClassName="absolute inset-0 w-full h-full object-cover"
                />
              ) : (
                <Image
                  src={props.heroImage}
                  alt={props.heroImageAlt}
                  fill
                  priority
                  unoptimized={isAnimated(props.heroImage)}
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, (max-width: 1280px) 90vw, 1100px"
                />
              )}
            </div>
          )}

          {/* Metadata block */}
          <div className="mt-12 md:mt-16 grid grid-cols-2 md:grid-cols-4 gap-x-6 gap-y-8 border-t border-border-subtle pt-10">
            {props.metadata.map((item) => (
              <div key={item.label}>
                <p className="metadata-label">({item.label})</p>
                <p className="metadata-value">{item.value}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ============================================================
          FIRST LOOK (optional)
          The first work visual, straight after the facts and before the
          challenge. No top border: it reads as the end of the hero, not
          a new chapter. firstLookImages brings the shared grid in the
          page container; firstLook is a block with its own container.
          ============================================================ */}
      {props.firstLookImages && props.firstLookImages.length > 0 && (
        <section>
          <div className="max-w-content mx-auto px-6 md:px-8 lg:px-12 pb-16 md:pb-24">
            <ImageGrid images={props.firstLookImages} />
          </div>
        </section>
      )}
      {props.firstLook}

      {/* ============================================================
          THE CHALLENGE, opened by the lead pull quote (epigraph).
          The quote moved here from the hero in November 2026 so the
          first look sits directly under the metadata.
          ============================================================ */}
      <section className="section border-t border-border-subtle">
        <div className="max-w-content mx-auto px-6 md:px-8 lg:px-12">
          {leadQuote && (
            <blockquote className="mb-12 md:mb-16 max-w-3xl hash-rule pl-6 md:pl-10 py-2">
              <p className="body-text text-xl md:text-2xl text-text-primary italic text-pretty">
                {"\u201C"}
                {leadQuote}
                {"\u201D"}
              </p>
            </blockquote>
          )}
          <h2 className="section-title">
            The business need
          </h2>
          <div className="max-w-3xl text-lg text-text-secondary prose-block">
            {props.challenge.map((para, i) => (
              <p key={i}>{para}</p>
            ))}
          </div>
        </div>
      </section>

      {/* ============================================================
          THE APPROACH + optional pull quote (section epigraph)
          ============================================================ */}
      <section className="section border-t border-border-subtle">
        <div className="max-w-content mx-auto px-6 md:px-8 lg:px-12">
          {restQuotes.length > 0 && (
            <blockquote className="mb-12 md:mb-16 max-w-3xl hash-rule pl-6 md:pl-10 py-2">
              {restQuotes.map((line, i, arr) => (
                <p
                  key={i}
                  className={`body-text text-xl md:text-2xl text-text-primary italic text-pretty${
                    i > 0 ? " mt-4 md:mt-5" : ""
                  }`}
                >
                  {i === 0 && "\u201C"}
                  {line}
                  {i === arr.length - 1 && "\u201D"}
                </p>
              ))}
            </blockquote>
          )}

          {props.afterQuote && (
            <div className="mb-12 md:mb-16">{props.afterQuote}</div>
          )}

          <CollapsibleSection id="approach-detail" heading="How I solved it">
            <div className="max-w-3xl text-lg text-text-secondary prose-block">
              {props.approach.map((para, i) => (
                <p key={i}>{para}</p>
              ))}
            </div>
          </CollapsibleSection>
        </div>
      </section>

      {/* ============================================================
          PROCESS CAROUSEL (optional)
          Renders here between the approach block and outcomes.
          The component supplies its own borders, padding, and section
          wrapper, so we simply slot it in.
          ============================================================ */}
      {props.processCarousel}

      {/* ============================================================
          MID IMAGES / VIDEO (optional)
          Renders prominently between the approach and the project
          showcases. Supports .mp4/.webm video (auto-plays muted, loops)
          via the same isVideo() detection used by bottomImages.
          Single item renders full-width 16:9; two items render 2-up.
          ============================================================ */}
      {props.midImages && props.midImages.length > 0 && (
        <section className="border-t border-border-subtle">
          <div className="max-w-content mx-auto px-6 md:px-8 lg:px-12 py-16 md:py-24">
            <ImageGrid images={props.midImages} />
          </div>
        </section>
      )}

      {/* ============================================================
          PROJECT SHOWCASES (optional)
          Each project: eyebrow, title, description paragraphs, optional images.
          Rendered after processCarousel, before The results.
          ============================================================ */}
      {props.projectShowcases && props.projectShowcases.length > 0 && (
        <section className="border-t border-border-subtle">
          <div className="max-w-content mx-auto px-6 md:px-8 lg:px-12 py-16 md:py-24 space-y-20 md:space-y-28">
            {props.projectShowcases.map((project, i) => (
              <article
                key={i}
                id={project.id}
                className="border-b border-border-subtle last:border-b-0 pb-20 md:pb-28 last:pb-0 scroll-mt-24 md:scroll-mt-32"
              >
                <div className="max-w-3xl">
                  <p className="eyebrow">{project.eyebrow}</p>
                  <h3 className="section-title">
                    {project.title}
                  </h3>
                  <div className="text-lg text-text-secondary prose-block">
                    {project.description.map((para, p) => (
                      <p key={p}>{para}</p>
                    ))}
                  </div>

                  {project.links && project.links.length > 0 && (
                    <div className="mt-7 md:mt-8 flex flex-wrap gap-3">
                      {project.links.map((link, li) => (
                        <a
                          key={li}
                          href={link.href}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center justify-center px-5 py-2.5 rounded-full bg-text-primary text-text-inverse text-sm font-medium tracking-tight hover:scale-[1.02] transition-transform"
                        >
                          {link.label}
                          <span aria-hidden="true" className="ml-2">
                            →
                          </span>
                        </a>
                      ))}
                    </div>
                  )}
                </div>

                {project.customContentBefore && (
                  <div className="mt-10 md:mt-14">{project.customContentBefore}</div>
                )}

                {project.images && project.images.length > 0 && (
                  <div
                    className={`mt-10 md:mt-14 grid gap-6 md:gap-8 ${
                      project.images.length > 1
                        ? "grid-cols-1 md:grid-cols-2"
                        : "grid-cols-1"
                    }`}
                  >
                    {project.images.map((image, ix) =>
                      image.browserFrame ? (
                        <div
                          key={ix}
                          className={`w-full ${
                            image.maxWidthClass
                              ? `${image.maxWidthClass} mx-auto`
                              : ""
                          }`}
                        >
                          <BrowserFrame
                            src={image.src}
                            url={image.browserFrame.url}
                            ariaLabel={image.alt}
                            theme="dark"
                            aspectRatio={image.browserFrame.aspectRatio}
                          />
                        </div>
                      ) : (
                        <div
                          key={ix}
                          className={`relative w-full overflow-hidden rounded-xl border border-border-subtle bg-bg-elevated shadow-2xl ${
                            image.maxWidthClass
                              ? `${image.maxWidthClass} mx-auto`
                              : ""
                          }`}
                        >
                          <Image
                            src={image.src}
                            alt={image.alt}
                            width={1920}
                            height={1080}
                            sizes="(min-width: 1024px) 50vw, 100vw"
                            unoptimized={isAnimated(image.src)}
                            className="w-full h-auto block"
                          />
                        </div>
                      )
                    )}
                  </div>
                )}

                {project.customContent && (
                  <div className="mt-12 md:mt-16">{project.customContent}</div>
                )}
              </article>
            ))}
          </div>
          {props.afterShowcases && (
            <div className="max-w-content mx-auto px-6 md:px-8 lg:px-12 pb-16 md:pb-24">
              <div className="max-w-3xl">{props.afterShowcases}</div>
            </div>
          )}
        </section>
      )}

      {/* ============================================================
          SELECTED OUTCOMES + optional bottom images
          ============================================================ */}
      <section className="section border-t border-border-subtle">
        <div className="max-w-content mx-auto px-6 md:px-8 lg:px-12">
          <h2 className="section-title">
            The results
          </h2>
          <div className="space-y-8 md:space-y-10 max-w-3xl">
            {props.outcomes.map((outcome, i) => (
              <div
                key={i}
                className="hash-rule pl-6 md:pl-8"
              >
                <p className="text-lg md:text-xl font-semibold text-text-primary mb-2 leading-tight">
                  {outcome.headline}
                </p>
                <p className="body-text text-base md:text-lg text-text-secondary">
                  {outcome.description}
                </p>
              </div>
            ))}
          </div>

          {props.bottomImages && props.bottomImages.length > 0 && (
            <div className="mt-16 md:mt-20 card-grid grid-cols-1 md:grid-cols-2">
              {props.bottomImages.map((img) => (
                <div
                  key={img.src}
                  className="relative aspect-[4/3] rounded-xl overflow-hidden border border-border-default"
                >
                  {isVideo(img.src) ? (
                    <video
                      src={img.src}
                      poster={img.poster}
                      autoPlay
                      loop
                      muted
                      playsInline
                      preload="metadata"
                      aria-label={img.alt}
                      className="absolute inset-0 w-full h-full object-cover"
                    />
                  ) : (
                    <Image
                      src={img.src}
                      alt={img.alt}
                      fill
                      className="object-cover"
                      unoptimized={isAnimated(img.src)}
                      sizes="(max-width: 768px) 100vw, 50vw"
                    />
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* ============================================================
          CLOSER HERO (optional full-width image before "The impact")
          ============================================================ */}
      {props.closerHero && (
        <section className="border-t border-border-subtle section">
          <div className="max-w-content mx-auto px-6 md:px-8 lg:px-12">
            <div className="relative w-full overflow-hidden rounded-xl border border-border-subtle bg-bg-elevated shadow-2xl">
              <Image
                src={props.closerHero.src}
                alt={props.closerHero.alt}
                width={1920}
                height={1440}
                sizes="(min-width: 1280px) 1280px, 100vw"
                className="w-full h-auto block"
                priority={false}
              />
            </div>
          </div>
        </section>
      )}

      {/* ============================================================
          WHAT THIS MEANS (closer)
          ============================================================ */}
      <section className="section border-t border-border-subtle">
        <div className="max-w-content mx-auto px-6 md:px-8 lg:px-12">
          <CollapsibleSection id="closer-detail" heading="The impact">
            <div className="max-w-3xl text-lg md:text-xl text-text-primary prose-block">
              {props.closer.map((para, i) => (
                <p key={i}>{para}</p>
              ))}
            </div>
          </CollapsibleSection>
        </div>
      </section>

      {/* ============================================================
          CTA BLOCK
          ============================================================ */}
      <section className="section-close border-t border-border-subtle">
        <div className="max-w-content mx-auto px-6 md:px-8 lg:px-12 text-center">
          <h2 className="section-title max-w-3xl mx-auto">
            {props.ctaHeadline}
          </h2>
          <div className="flex flex-col sm:flex-row gap-4 sm:items-center sm:justify-center">
            <Link
              href="/contact"
              className="inline-flex items-center justify-center px-7 py-3.5 rounded-full bg-text-primary text-text-inverse text-base font-medium tracking-tight hover:scale-[1.02] transition-transform"
            >
              Talk through something similar
              <span aria-hidden="true" className="ml-2">&rarr;</span>
            </Link>
            <Link
              href="/engagements"
              className="inline-flex items-center justify-center text-base font-medium text-link hover:text-link-hover transition-colors"
            >
              See other engagements{" "}
              <span aria-hidden="true" className="ml-2">
                →
              </span>
            </Link>
          </div>
        </div>
      </section>

      {/* ============================================================
          RELATED WORK
          ============================================================ */}
      {props.related && props.related.length > 0 && (
        <section className="section border-t border-border-subtle">
          <div className="max-w-content mx-auto px-6 md:px-8 lg:px-12">
            <p className="eyebrow">Related work</p>
            <h2 className="section-title">
              Related projects
            </h2>
            <div className="card-grid grid-cols-1 md:grid-cols-2">
              {props.related.map((rel) => (
                <Link
                  key={rel.slug}
                  href={`/work/${rel.slug}`}
                  className="group relative block card hover:border-border-strong transition-colors"
                >
                  <div className="relative aspect-[16/10]">
                    <Image
                      src={rel.image}
                      alt=""
                      fill
                      className="object-cover"
                      unoptimized={isAnimated(rel.image)}
                      sizes="(max-width: 768px) 100vw, 50vw"
                    />
                  </div>
                  <div className="card-body">
                    <p className="eyebrow">{rel.eyebrow}</p>
                    <h3 className="card-title text-text-primary group-hover:text-link transition-colors">
                      {rel.title}
                    </h3>
                    <p className="card-text mt-3 text-text-secondary text-sm">
                      {rel.description}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
    </article>
  );
}
