import Image from "next/image";
import Link from "next/link";

/**
 * HeroBottom: three doors, named by what the visitor came to do.
 *
 * Reading flow on the homepage: Hero (image + headline), LogoStrip, then
 * this block. It replaces the old audience line and CTA pair with three
 * intent-named entry points, because a visitor does not know which audience
 * they are on arrival, but they do know what they came to do.
 *
 *   Door 1  Share your business goals             /contact (the page's one ask)
 *   Door 2  The work behind the experience        /work
 *   Door 3  The thinking I bring, as a system     /thinking, the Process page
 *
 * The D&AD line sits underneath the doors as a credential, shown, not
 * claimed, and links to the D&AD entry. It moved into a proof strip for a
 * while in October 2026 and came back here when the strip was removed.
 *
 * To retune a door, edit DOORS below. Door 1 keeps `primary` for its copy
 * and link order only; the three borders match.
 * Since October 2026 it goes to /contact, where the visitor picks the
 * calendar, email, or phone, instead of straight to the calendar.
 */

type Door = {
  key: string;
  eyebrow: string;
  title: string;
  body: string;
  cta: string;
  href: string;
  external?: boolean;
  primary?: boolean;
};

const DOORS: Door[] = [
  {
    key: "problem",
    eyebrow: "Start here",
    title: "Share your business goals or roadblocks.",
    body: "A stuck flow, a message that isn't getting the action you want, or customer signals nobody tracks. I find the opportunities, drive product to market, and build feedback loops that turn customer data into actionable business intelligence.",
    cta: "Tell me what you\u2019re working on",
    href: "/contact",
    primary: true,
  },
  {
    key: "work",
    eyebrow: "Proof",
    title: "The work behind the experience.",
    body: "Six case studies across pharma, healthcare, financial services, and enterprise, from design governance and patient navigation to CRM, CX, and independent products.",
    cta: "See the case studies",
    href: "/work",
  },
  {
    key: "thinking",
    eyebrow: "Method",
    title: "The thinking I bring to every discussion, built into a flexible system.",
    body: "I brought the way I think, collaborate, and make decisions into a system teams can use, from seasoned strategy and product teams to those new to the process. Digital, printed, and in your pocket.",
    cta: "See the Process",
    href: "/thinking",
  },
];

export function HeroBottom() {
  return (
    <section className="pt-12 md:pt-12 pb-14 md:pb-20">
      <div className="relative max-w-content mx-auto px-6 md:px-8 lg:px-12">
        <div className="card-grid grid-cols-1 md:grid-cols-3">
          {DOORS.map((door) => {
            /* All three doors share one border (November 2026). The first
               door used to carry a purple edge as the primary ask; it read
               as a mismatch, and its button already says "start here". */
            const cardClass =
              "group relative flex flex-col card transition-colors";
            const inner = (
              <>
                <p className="metadata-label">
                  {door.eyebrow}
                </p>
                <h2 className="card-title text-text-primary text-balance">
                  {door.title}
                </h2>
                <p className="card-text text-sm md:text-base text-text-secondary text-pretty flex-1">
                  {door.body}
                </p>
                <p
                  className="card-foot inline-flex items-center text-sm font-medium transition-colors text-link group-hover:text-link-hover"
                >
                  {door.cta}
                  <span aria-hidden="true" className="ml-2">
                    &rarr;
                  </span>
                </p>
              </>
            );
            return door.external ? (
              <a
                key={door.key}
                href={door.href}
                target="_blank"
                rel="noopener noreferrer"
                className={cardClass}
              >
                {inner}
              </a>
            ) : (
              <Link key={door.key} href={door.href} className={cardClass}>
                {inner}
              </Link>
            );
          })}
        </div>

        <a
          href="https://www.dandad.org/annual/2022/entry/professional/235946"
          target="_blank"
          rel="noopener noreferrer"
          className="mt-8 md:mt-10 inline-flex items-center gap-2 text-sm italic font-light text-text-tertiary hover:text-text-secondary transition-colors"
        >
          <Image
            src="/images/awards/dandad-pencil-2022.webp"
            alt="D&AD Pencil 2022 award"
            width={300}
            height={300}
            className="h-10 w-10 shrink-0 rotate-90"
          />
          <span>D&amp;AD Pencil 2022, Future Impact, with The Chrysalis Initiative</span>
        </a>
      </div>
    </section>
  );
}
