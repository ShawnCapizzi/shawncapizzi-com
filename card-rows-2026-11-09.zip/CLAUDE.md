# shawncapizzi.com

Personal brand site for Shawn Capizzi — Director of UX, AI experience architect, 
and author of "Seeing Past the Cage: Better Communication Design in the Age of AI."
The site called the book "Clarity Is the Advantage" until September 2026; that
phrase now appears only as the brand line in the footer.

The thesis: **AI adoption is not a technology problem. It is an experience 
architecture problem.** Every page, every word, every visual decision reinforces this.

## Architecture

Eight-page site. Three conversion paths in priority order:

- **Path A**: Direct: Home → Engagements → Contact (calendar, email, or phone)
- **Path B**: Content-led: Home → Case Study → Contact
- **Path C**: Lead capture: Home → Thinking (/thinking) → Email → Drip → Booking

Full site map and per-page specs in `docs/ia-framework-v1-1.md`.

## Design system

All visual decisions follow `docs/design-system.md`. This is non-negotiable.

- Do not introduce new color tokens, type scale, spacing values, or components 
  without referencing this file
- Tokens are defined in `app/globals.css` using Tailwind v4's `@theme` block — 
  edit there, not in `tailwind.config.js` (which doesn't exist in v4)
- Anti-patterns are listed in section 8 of the design system — read them before 
  introducing any new pattern
- Heading sizes come from four type roles in `app/globals.css`, never from
  per-element size utilities: `.hero-title` (page H1, 30px then 39px from
  1024px), `.hero-lead` (paragraph under the H1, Instrument Sans 20/28),
  `.section-title` (every section H2 and closing ask, 30px), and `.card-title`
  (card and panel titles, 20px then 24px from 768px). Page heroes pair
  `.hero-title` with `.headline-static`; only the homepage uses
  `.headline-gleam`. Page content sits in `max-w-content`; `max-w-wide` is for
  the header, footer, and logo strip only.

## Content

- Page copy lives in `docs/manuscript-v2-2.md` — use these exact words, do not 
  paraphrase or invent voice
- Voice principles in design system §1: senior, direct, editorial, restrained
- Anti-voice list is enforced: no "we", no "crafted/elevated/journey", no 
  motivational copy, no SaaS marketing tone
- No criticism of other consultants, agencies, or AI builders (September
  2026). Describe Shawn's own part instead: defining the problem, directing
  the tools, refining the experience, making tradeoffs, and shipping
  something usable, with specific decisions and artifacts as evidence.
- Where interviews and AI-assisted simulations both appear, keep them
  distinct: interviews are with real stakeholders; simulations are labeled
  and reported separately.

## Stack

- Next.js 16 (App Router) with Turbopack
- TypeScript
- Tailwind CSS v4 (config via `@theme` in globals.css, not a JS config file)
- Instrument Sans (all headings), Geist (body), Geist Mono (labels), all via
  `next/font/google` in `app/layout.tsx`. Nunito Sans was retired in September
  2026. Heading rules in `app/globals.css` are unlayered on purpose, so they
  win over Tailwind utilities on h1, h2, and h3.
- `/design-info` (`app/design-info/page.tsx`, linked from the footer's palette
  emoji) lists the fonts, the six core colors with nearest PANTONE Solid
  Coated matches (pantone-cli, CIEDE2000, cross-checked against two other
  datasets), and the stack. It replaced the `/about#colophon` section in
  October 2026. If a color token changes, re-run the match and update that
  file; hex values there must equal the tokens exactly.
- MDX for case studies and essays (to be added)
- Deployed on Vercel, auto-deploy on `git push` to `main`

## SEO and GEO

Set up September 2026. The canonical host is `https://shawncapizzi.com`
(`SITE_URL` in `lib/seo.ts`); canonicals, the sitemap, robots.txt, and all
structured data use it.

- Every page builds its metadata with `pageMetadata()` from `lib/seo.ts`. It
  sets the canonical, Open Graph, X card, and share image together. Never
  export a bare `{ title, description }`: Next.js does not merge openGraph,
  so the page would inherit the homepage's og:title and og:url.
- A page with `"use client"` cannot export metadata. Keep pages as server
  components and move interactive parts into a component (see /faq and
  `components/FaqAccordion.tsx`).
- One H1 per page. Components that render inside a page (the Reader, cards)
  start at h2.
- Structured data (JSON-LD) says only what the page shows. The Person node
  (`@id` `https://shawncapizzi.com/#person`) is rendered once in the root
  layout; case studies (Article plus breadcrumbs), /about (ProfilePage),
  /faq (FAQPage, from `lib/faq.ts`), and /book/chapter-1 (Book) point to it.
  `sameAs` lists only profiles the site itself links (LinkedIn today).
- Share images are 1200x630 JPEGs in `public/images/og/`: `og-default.jpg`,
  one per case study named by slug, and `seeing-past-the-cage.jpg`. They were
  rendered from HTML with the site's fonts and colors. A new case study needs
  its own image, or it falls back to the default.
- robots.txt allows every crawler, AI training included (Shawn's call,
  September 2026), and names the answer-engine crawlers on their own.
  `/api/` is disallowed. No llms.txt: Google says Search ignores it.
- Titles under about 60 characters, descriptions under about 160, and one
  consistent set of facts everywhere (fifteen years, not "a decade").

## File conventions

- Components in `/components`, one file per component, PascalCase
- Page routes in `/app/[route]/page.tsx`
- Long-form content as MDX in `/content/case-studies` and `/content/thinking`
- Images in `/public/images/{brand|hero|case-studies|logos|practice-grid}/`
- Use Next.js `<Image>` component for all imagery (not raw `<img>` tags)

## Asset inventory

- `public/images/brand/signature-logo.svg` — the handwritten Capizzi wordmark
- `public/images/brand/wordmark-full.svg` — composed wordmark with portrait (unused, kept for reference)
- `public/images/brand/headshot-2026.png` — hero portrait (B&W, soft gray bg)
- `public/images/logos/` — 6 client logos, monochrome white, numbered 01–06 in display order
- `public/images/case-studies/` — case study hero images
- `public/images/hero/` — hero supporting imagery
- `public/images/practice-grid/` — practice-area visuals

Symbol mark SVG (the 16-point starburst) is **not yet created** — use a 
placeholder in components that reference it until the asset is finalized.

## Conversion infrastructure

- Booking URL: `https://cal.com/capizzi/30min`, opened only from the Contact
  page's "Open the calendar" button. Since October 2026 every general CTA
  ("Let's talk", "Start a conversation", "Tell me what you're working on",
  and "Talk through something similar" on case studies) goes to /contact.
  "Strategy Call" is retired; the first step is the "Initial Conversation".
- Email service: TBD (ConvertKit vs Mailchimp — see open questions in IA doc §13)
- Phone: 212-380-3900 (footer + contact page only, not body copy)
- Email: capizzi@gmail.com

## Forbidden patterns

The design system §8 anti-patterns are enforced. Most-violated to watch for:

- No bullet-point overuse — prose first, lists only when essential
- No agency-speak: "crafted", "elevated", "transformed", "delighted", "journey"
- No "we" — Shawn is one person. One exception (Shawn's call, November
  2026): the Advisory shape cards on /engagements say "we" because there it
  means Shawn and the client working the problem together.
- No drop shadows for elevation (use bg shifts)
- No more than 3 colors visible on a page
- No icons or illustrations beyond the single starburst symbol, with two
  exceptions (Shawn's call, October 2026): the hand-drawn Process action
  sketches in `components/ProcessSketch.tsx`, his bulb language, and the same
  bulb language reused on `/how-i-help` in `components/WaysSketch.tsx`: three
  drawings, one per Process principle (Listen first, Make it visible, Prove it
  worked), each shown once as the header above that principle's list of
  "ways" (a divider list since November 2026, no cards), lighting in on
  scroll, no hover
- No motion that isn't tied to scroll, hover, or page transition, with one
  exception (Shawn's call, October 2026): the slow breeze sway and
  traveling purple tint on the Process sketches' shade ticks

## Vertical rhythm (November 2026)

- Type spaces itself. The roles in `app/globals.css` carry the gap to
  whatever follows them, from six tier-2 tokens on an 8px base:
  `--space-after-eyebrow` 16, `--space-after-hero-title` 24,
  `--space-after-title` 24, `--space-after-card-title` 12,
  `--space-paragraph` 24, `--space-paragraph-card` 16. Pages set no
  margin utilities on an eyebrow, title, or lead, and no `mt-*` on the
  element after one; both stack with the role and break the rhythm.
- Leading is a property of the style, never the page (Apple HIG shape:
  tighter as size grows, loose for long passages). Titles 1.05 to 1.25,
  `.hero-lead` 1.4, `.body-text` 1.6 with 24px between paragraphs,
  `.card-text` 1.6 with 16px, `.small-text` 14px at 1.5, labels 1.4,
  `.lead-text` 1.6, and `.prose-block` for a container of several
  paragraphs (it carries the leading and the 24px between children). The
  body default is 1.6 too, so an unclassed paragraph still lands on the
  system. `leading-*` utilities no longer appear on text anywhere in the
  site; use the roles.
- Measured with Playwright across ten pages after the change: eyebrow to
  heading 16 everywhere, section title to text 24, card title to text 12.
  Before, section titles ran 16 to 56 and card titles 8 to 28.
- Sections breathe from four roles, never from `py-*` on the element:
  `.section` (48 phone / 64 tablet / 80 desktop each side), `.section-close`
  (64 / 80 / 96, the closing ask and testimonials only), `.section-tight`
  (32 / 40 / 48, strips and bands that belong to the section above), and
  `.section-hero` (128 / 160 top to clear the fixed header, a body
  section's bottom). Two sections meeting at a border show double the
  value. Before, 76 sections used 18 padding recipes; the homepage ran
  its ordinary sections at the closing-ask size, which is why it breathed
  differently from the other pages. The homepage hero, the contact hero,
  and the FAQ list tail keep their own padding on purpose.
- Cards are one role: `.card` is the whole recipe (surface, 1px default
  border, 16px radius, inset 24 phone / 28 tablet / 32 desktop from
  `--space-card`). A card with an image above its text puts the inset on a
  `.card-body` child so the image runs to the edge. `.card-compact` (16 /
  20 / 24) is for dense rows only: the carousel panels, the fragmentation
  grid, the book contents. Pages set no `p-*`, `rounded-*`, or `border`
  on a card. Before, 27 cards used 11 insets (16 to 40px) and two radii;
  measured after, every card on nine pages reads 24 / 32 at 16px radius.
  `.card-surface` remains as the shared surface paint only.
- Cards in a row share the row's height. Content stacks from the top on
  the 24px rhythm; the last action carries `.card-foot`, which puts every
  link or button in the row on one baseline with 24px above it. The copy
  in a row is balanced to within a line of the tallest card, so the air
  above the foot never reads as a hole; when a row looks uneven, fix the
  copy, not the rule. Pages set no `mt-*`, `mt-auto`, or `flex-1` on
  card children. Text-only rows (Three ways, testimonials) have no foot
  and simply stack.
- The gutter between cards or image tiles in a row is `.card-grid`: gap
  from `--space-card`, so gutter equals inset (24 / 28 / 32). Pages add
  only `grid-cols-*`; never a `gap-*` on a card grid. Before, 16 card
  grids used five gap recipes (20 to 40px).

## Color meaning (November 2026)

- Lavender (`--color-link`, `#A798FF`) means a thing can be acted on: links,
  button text, and the active item in a loop or list (the current Process
  move, the current chapter). Nothing else is lavender. Labels, eyebrows,
  captions, and metadata are `text-tertiary` gray in mono. Shawn's rule:
  color has meaning, and a label in link color reads as a link on a phone.

## Type voices (November 2026)

- Three faces, three jobs: Instrument Sans for headings and the hero lead,
  Geist for body and buttons, Geist Mono for labels only. `.eyebrow` and
  `.metadata-label` are both mono, so every small uppercase label on the
  site is one voice; mono never sets a sentence. The homepage hero carries
  no credential line and no second wordmark: the 15+ years sits in the
  lead, and the header already shows the mark.

## Accordions (November 2026)

- One pattern, `.disclosure-list` and `.disclosure-item` in
  `app/globals.css`: a hairline above the first item and below each, no
  fill, no outline, title in the `.card-title` role, chevron at the right,
  items padded `py-6 md:py-7`, detail `pb-7 md:pb-8`. Used by
  `components/WaysGroups.tsx` (/how-i-help) and `components/FaqAccordion.tsx`
  (/faq). A single collapsed section (`components/CollapsibleSection.tsx`:
  case study How I solved it and The impact, the Lab's Earlier experiments)
  carries no hairlines of its own, since its section already has one; it is
  an H2 in the `.section-title` role with the chevron at the right, and the
  prose opens beneath. Cards and filled
  accordions were retired (Shawn's call): filled, they competed with the
  page; unfilled, they read as a stack of dark boxes on a phone.
  `components/AccordionDetail.tsx` is unused and kept only until removed.

## Contrast (November 2026)

- `text-tertiary` is `#8C8C8C`, lifted from `#737373`, which failed AA for
  small text on every surface (4.07:1 on the page, 3.65:1 on cards). The
  new value measures 5.74:1 on `bg-primary`, 5.14:1 on `bg-raised`, and
  4.89:1 on `bg-elevated`. `bg-elevated` moved from `#021626` to `#08203A`
  (1.17:1 against the page, from 1.05:1) so the header, carousel frames,
  and video posters read as a step. `bg-raised` and `.card-surface` are
  unchanged on purpose (Shawn's call). Any component that needs these
  values in JS reads the CSS variable, never a hex copy.

## Case studies

- `components/CaseStudyLayout.tsx` renders every study. Since November 2026
  the order is: hero, metadata, **first look** (`firstLook` or
  `firstLookImages`), lead quote, The business need, How I solved it
  (collapsed), the remaining process sections, The results, The impact
  (collapsed), the ask, Related projects. Those five headings are the
  layout's and are chosen for a decision maker or a recruiter skimming:
  each answers a plain question (what was needed, what Shawn did, what
  happened, what it makes possible, what else). The page props keep their
  old names (`challenge`, `approach`, `outcomes`, `closer`). The first look is the
  page's first work visual, placed before the prose so a reader sees the
  work within about 1,300 to 1,700px on desktop (half the previous scroll,
  measured with Playwright across all six studies). A new case study passes
  its strongest visual block to `firstLook`; a carousel used there takes
  `className="pt-6 md:pt-8 pb-16 md:pb-24"`. The Lab page keeps its
  text-first showcases on purpose.

## Working principles

- Read the design system and IA framework before writing any new page
- Use existing tokens and components; create new ones only when justified
- Every change should be commitable as a single logical unit
- Mobile considerations are documented in IA §8 — design system is desktop-first 
  but mobile must work flawlessly
  